angular.module('InvoiceModule', [])


// The invoice displayed when the user first uses the app
.constant('DEFAULT_INVOICE', {
  tax: 2.5,
  invoice_number: 10,
  phoneno: 90909090,
  gstin: 90909090,
  date: '27/07/2017',
  pannumber: 'APTD7615A',
  email: 'Kishor.a@verizon.com',
  custOrderNo: '1234',
  dated: '27/07/2017',
  customer_info: {
	name: 'Kishor Enterprises',
    web_link: 'Kishor Inc.',
    address1: 'B.Shankarlal Nagar ,Erragadda,Hyderabad-500018,India',
    address2: 'Hyderabad-500018,India',
    postal: '500018'
  },
  company_info: {
    name: 'Kishor Labs',
    web_link: 'www.google.com',
    address1: 'Mindspace,Hitec City',
    address2: 'Hyderabad,India',
    postal: '500081'
  },
  items:[
    { qty: 2, description: 'Iphone', cost: 55000 }
  ]
})

// Service for accessing local storage
.service('LocalStorage', [function() {

  var Service = {};

  // Checks to see if an invoice is stored
  var hasInvoice = function() {
    return !(localStorage['invoice'] == '' || localStorage['invoice'] == null);
  };

  // Returns a stored invoice (false if none is stored)
  Service.getInvoice = function() {
    if (hasInvoice()) {
      return JSON.parse(localStorage['invoice']);
    } else {
      return false;
    }
  };

  Service.setInvoice = function(invoice) {
    localStorage['invoice'] = JSON.stringify(invoice);
  };

  // Clears a stored invoice
  Service.clearinvoice = function() {
    localStorage['invoice'] = '';
  };

  // Clears all local storage
  Service.clear = function() {
    localStorage['invoice'] = '';
  };
  return Service;

}])

.service('Currency', [function(){

  var service = {};
  service.all = function() {
    return [
      {
        name: 'Indian Rupee (?)',
        symbol: 'Rs.'
      },
      {
        name: 'US Dollar ($)',
        symbol: '$'
      }
    ]
  }
  return service;
  
}])

// Main application controller
.controller('InvoiceCtrl', ['$scope','$http','DEFAULT_INVOICE','LocalStorage','Currency',
  function($scope, $http, DEFAULT_INVOICE,LocalStorage,Currency) {

  // Set defaults
  $scope.currencySymbol = 'Rs.';
  $scope.printMode   = false;

  (function init() {
    // Attempt to load invoice from local storage
    !function() {
      var invoice = LocalStorage.getInvoice();
      $scope.invoice = invoice ? invoice : DEFAULT_INVOICE;
    }();

    $scope.availableCurrencies = Currency.all();

  })()
  // Adds an item to the invoice's items
  $scope.addItem = function() {
    $scope.invoice.items.push({ qty:0, cost:0, description:"" });
  }

  $scope.printInfo = function() {
    window.print();
  };

  // Remotes an item from the invoice
  $scope.removeItem = function(item) {
    $scope.invoice.items.splice($scope.invoice.items.indexOf(item), 1);
  };

  // Calculates the sub total of the invoice
  $scope.invoiceSubTotal = function() {
    var total = 0.00;
    angular.forEach($scope.invoice.items, function(item, key){
      total += (item.qty * item.cost);
    });
    return total;
  };

  // Calculates the tax of the invoice
  $scope.calculateTax = function() {
    return (($scope.invoice.tax * $scope.invoiceSubTotal())/100);
  };

  // Calculates the grand total of the invoice
  $scope.calculateGrandTotal = function() {
    saveInvoice();
    return $scope.calculateTax() + $scope.invoiceSubTotal();
  };

  // Clears the local storage
  $scope.clearLocalStorage = function() {
    var confirmClear = confirm('Are you sure you would like to clear the invoice?');
    if(confirmClear) {
      LocalStorage.clear();
      setInvoice(DEFAULT_INVOICE);
    }
  };

  // Sets the current invoice to the given one
  var setInvoice = function(invoice) {
    $scope.invoice = invoice;
    saveInvoice();
  };

  // Saves the invoice in local storage
  var saveInvoice = function() {
    LocalStorage.setInvoice($scope.invoice);
  };

  // Runs on document.ready
  angular.element(document).ready(function () {
    // Set focus
    document.getElementById('invoice-number').focus();
  });

}])
